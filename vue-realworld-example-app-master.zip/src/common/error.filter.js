export default errorValue => {
  return `${errorValue[0]}`;
};
