export const API_URL = "https://conduit.productionready.io/api";
export default API_URL;
